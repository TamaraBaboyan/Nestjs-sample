import { EntityRepository, Repository } from 'typeorm';
import { User } from './user.entity';
import { AuthCredentialsDto } from './dto/auth-credentials.dto';
import { ConflictException, InternalServerErrorException } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';

@EntityRepository(User)
export class UserRepository extends Repository<User> {

    async signUp(authCredentialsDto: AuthCredentialsDto): Promise<void> {
        const { username, password } = authCredentialsDto;

        /**
         * we want username to be unique. one method to achieve this is:
         * exists = this.findOne({username});
         * if (exists) {
         * // ... threow err
         * }
         * 
         * otherwise: save the user
         * 
         * we don't like this method, because we have to send two queries to save the user.
         * we will do this functionality using just one query BY:
         * defining the username column as unique in the database level, in our case in the Entity
         * 
         */

        const salt = await bcrypt.genSalt();    // salt is generated uniquely for each user, we use this hash to generate password
        // console.log(salt)

        const user = new User();
        user.username = username;
        user.salt = salt;
        user.password = await this.hashPassword(password, salt); // we also save the salt in the database, it's common practice and it's totally fine securitywise, sowe add a column in user entity to save user

        
        /**
         * when we save 2 same usernames, because it violiates username unique constraints we defined in DB level in entity.
         * 
         * when we don't wrap "user.save", In nestjs when err is thrown and didn't caught it bubbles up the err to all controller-handler level.
         * and when  handled anyway on the way, Nest JS automatically throws 500 internal server err.
         * 
         * when we wrap in try, catch, we see that err code = 23505
         */
        try {
            await user.save();
        } catch (err) {
            console.log(err.code) // each err thrown my typeORM has err code, we see that err code is 23505, that is err code for duplicate entity. we can use this to our advantage
            if (err.code === '23505') {
                throw new ConflictException('Username already exists');
            } else {
                throw new InternalServerErrorException();
            }
        }
        
    }

    async validateUser(authCredentialsDto: AuthCredentialsDto): Promise<string> {
        const { username, password } = authCredentialsDto;
        const user = await this.findOne({ username });

        if (user && await user.validatePassword(password)) {
            return user.username
        } else {
            return null // if we get null, either user doesn't exist OR password isn't correct
        }
    }

    private async hashPassword(password: string, salt: string) {
        return bcrypt.hash(password, salt);
    }
}

/**
 * As salt will be unique for each user, the password will be unique, even if some users have thes same password.
 * 
 * The purpose of the salt:
 * ========================
 * as encryption and decryption follow certain algorithm(such as sha256), so encrypted passwords can easily be decrypted and the plain text find out and this securit issue.
 * So, we generate a salt unique for each user and we encrypt the password using that salt.
 * As a result, the encrypted psw cann't be decrpyted using the algorithm
 * 
 */